#include <iostream>
using namespace std;

int main(){
	double a[5]={15.95,24.95,6.95,12.95,3.95};
	double h=0;
	for(int i=0;i<5;i++){
			h=h+a[i];
			cout << a[i] << endl;
	}
	double taxes=h*0.07;
	double total=h+taxes;
	cout << h << endl << taxes << endl << total;
	return 0;
}
