#include <iostream>
using namespace std;

int main(){
	float charge=88.67;
	float tax=0.0675;
	float tip=0.2;
	float taxamount=charge*tax;
	float tipamount=charge*tip;
	float totalbill=charge+taxamount+tipamount;
	cout << charge << endl << taxamount << endl << tipamount << endl << totalbill;
}
