#include <iostream>
using namespace std;

int main(){
	double mpy,j,k,m;
	mpy=1.5;
	j=mpy*5;
	k=mpy*7;
	m=mpy*10;
	cout << j << " " << k << " " << m << " ";
	return 0;
}
