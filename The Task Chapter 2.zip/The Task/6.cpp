#include <iostream>
using namespace std;

int main(){
	int payAmount=2200;
	int payPeriods=26;
	int annualPay=payAmount*payPeriods;
	cout << annualPay;
	return 0;
}
