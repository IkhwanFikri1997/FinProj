#include <iostream>
using namespace std;

int main(){
	double acres=43.560;
	double total=391.876;
	double acresHa=total/acres;
	cout << acresHa;
	return 0;
}
