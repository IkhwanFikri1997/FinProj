#include <iostream>
using namespace std;

int main(){
	int purchase=95;
	float sst=0.04;
	float cst=0.02;
	float tst;
	tst=(purchase*sst)+(purchase*cst);
	cout << tst;
	return 0;
}
