#include <iostream>
using namespace std;

int main(){
	double customers=16500;
	double prefer=0.15;
	double prefer2=0.58;
	cout << customers*prefer << endl << customers*prefer2;
	return 0;
}
