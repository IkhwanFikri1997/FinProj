#include <iostream>
using namespace std;

int main(){
	double num[5]={28,32,37,24,33};
	double k=0;
	for(int i=0;i<=4;i++){
		k=k+num[i];
	}
	double j=k/5;
	cout << j;
	return 0;
}
