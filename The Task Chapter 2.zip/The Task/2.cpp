#include <iostream>
using namespace std;

int main(){
	float eastcoast;
	eastcoast=8.6*0.58;
	cout << eastcoast; 
	return 0;
}
