#include <iostream>
using namespace std;

int main(){
	int x=50;
	int y=100;
	int total=x+y;
	cout<<total;
	return 0;
}
