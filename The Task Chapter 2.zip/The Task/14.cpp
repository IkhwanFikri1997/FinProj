#include <iostream>
using namespace std;

int main (){
	cout << "My Name is Ikhwan Fikri Nur Afra" << endl 
	<< "I'm live at Binus Square" << endl 
	<< "My phone Number is 082153019709" << endl 
	<< "My major is Computer Science";
	return 0;
}
