#include <iostream>
using namespace std;

int main(){
	double gallons=20;
	double averageTown=23.5;
	double averageHighway=28.9;
	double distanceTown=gallons*averageTown;
	double distanceHighway=gallons*averageHighway;
	cout << distanceTown << endl << distanceHighway;
	return 0;
}
