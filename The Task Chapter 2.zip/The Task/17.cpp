#include <iostream>
using namespace std;

int main(){
	double shares=750;
	double price=35;
	double comm=0.02;
	double paidwithoutcomm=shares*price;
	double amountcomm=paidwithoutcomm*comm;
	double totalamount=paidwithoutcomm+amountcomm;
	cout << paidwithoutcomm << endl << amountcomm << endl << totalamount;
	return 0;
}
