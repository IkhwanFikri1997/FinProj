#include <iostream>
using namespace std;

int main(){
	int miles,gallons;
	float mpg;
	cin >> miles;
	cin >> gallons;
	mpg = miles/gallons;
	cout << mpg;
	return 0;
}
