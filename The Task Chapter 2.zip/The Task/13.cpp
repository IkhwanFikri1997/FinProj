#include <iostream>
using namespace std;

int main(){
	double percent=0.35;
	double costprice=14.95;
	double sellprice=costprice+(costprice*percent);
	cout << sellprice;
	return 0;
}
