#include <iostream>
using namespace std;

int main(){
	int i;
	int k;
	int b;
	scanf("%d",&i);
	for (b=1;b<=i;b++){
		for(k=1;k+b<=i;k++){
			cout << " ";
		}
		for(k=1;k<=b*2-1;k++){
			cout << "*";
		}
		cout << endl;
	}
	return 0;
}
