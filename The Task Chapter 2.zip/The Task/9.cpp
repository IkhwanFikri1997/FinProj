#include <iostream>
using namespace std;

int main(){
	cout << "char size is: "<< sizeof(char) << " byte" << endl;
	cout << "int size is: "<< sizeof(int) << " bytes" << endl;
	cout << "float size is: "<< sizeof(float) << " bytes" << endl;
	cout << "double size is: "<< sizeof(double) << " bytes" << endl;
	
	return 0;
}
